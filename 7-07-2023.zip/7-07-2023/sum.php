<html>
    <body>
        <form method="post">
            Enter First number:
            <input type="number" name="number1"  /><br><br> 
            Enter second number:
            <input type="number" name="number2"  /><br><br>
            <input type="submit" name="submit"  value="Add">
</form>
<?php
   if(isset($_POST['submit']))
   (
    $number1= #_POST['number1'];
    $number1= #_POST['number2'];
    $Sum = $number1 + $number2;
    echo "The sum of $number1 and $number2 is: ".$sum;
   )
   ?>


</body>
</html>
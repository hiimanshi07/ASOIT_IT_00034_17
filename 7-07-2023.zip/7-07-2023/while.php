<!DOCTYPE html>
<html>
<body>

<?php
$x = 10;  

while($x <= 100) {
  echo "The number is: $x <br>";
  $x+=10;
}
?>  

</body>
</html>
